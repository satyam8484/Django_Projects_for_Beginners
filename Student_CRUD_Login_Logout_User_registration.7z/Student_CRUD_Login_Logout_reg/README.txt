in Student_CRUD_Login_Logout_reg\Student_Project>  run following Command
python manage.py runserver
	