from django.apps import AppConfig


class MailappConfig(AppConfig):
    name = 'MailApp'
