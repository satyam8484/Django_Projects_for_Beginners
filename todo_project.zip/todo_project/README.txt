Run : -
open cmd 
Go inside using cd
ToDo_Project ---> run "python manage.py runserver"
& browse this  http://127.0.0.1:8000/  